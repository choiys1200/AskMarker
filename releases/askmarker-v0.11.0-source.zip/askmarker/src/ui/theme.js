'use strict';
const {themePalette}=require('../domain/theme');
// Namespaced inherited tokens affect extension-owned CSS only. No record writes.
function applyTheme(node,color){const palette=themePalette(color);for(const[key,value]of Object.entries(palette.tokens))node.style.setProperty(key,value);return palette;}
function applyCommentColor(card,color){const p=themePalette(color);card.style.setProperty('--accent',p.solid);card.style.setProperty('--accent-rgb',p.rgb);card.style.setProperty('--comment-light-ink',p.commentLightInk);card.style.setProperty('--comment-dark-ink',p.commentDarkInk);}
module.exports={applyTheme,applyCommentColor};
